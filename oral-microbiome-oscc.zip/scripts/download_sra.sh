#!/bin/bash
# Download and convert a single SRA file
prefetch SRR25380167 --output-directory ./data
fasterq-dump ./data/SRR25380167.sra --outdir ./data --split-files --threads 4
