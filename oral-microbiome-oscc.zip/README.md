
# Oral Microbiome OSCC Project

This repository contains the complete pipeline for analyzing salivary microbiome 16S rRNA data for oral squamous cell carcinoma (OSCC) biomarker discovery using QIIME2 and machine learning (scikit-learn).

## Structure

- `notebooks/`: Google Colab notebook for machine learning analysis
- `metadata/`: Sample metadata files
- `scripts/`: Bash scripts to download SRA data
- `data/`: Place your raw FASTQ or SRA files here
- `results/`: Store your processed results and figures here

## Instructions

1. Download 16S rRNA FASTQ data using `scripts/download_sra.sh`
2. Analyze data using QIIME2 (import, denoise, taxonomy, diversity)
3. Export data and use Colab notebook for ML
4. Visualize and report biomarkers for OSCC

## Requirements

- QIIME2 (Amplicon distribution)
- Python 3 (scikit-learn, pandas, seaborn, matplotlib)
- Google Colab

---

Project by Arun Kumar Arul Dass | Department of Bioinformatics
